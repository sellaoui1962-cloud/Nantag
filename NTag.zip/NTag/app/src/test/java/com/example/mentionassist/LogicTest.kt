package com.example.mentionassist

import com.example.mentionassist.core.MentionHistory
import com.example.mentionassist.core.TimerTracker
import org.junit.Assert.*
import org.junit.Test

class LogicTest {
    @Test fun suffixAlternates() {
        val h = MentionHistory()
        assertEquals(" .", h.nextSuffix()); h.commit()
        assertEquals(" ..", h.nextSuffix()); h.commit()
        assertEquals(" .", h.nextSuffix()); h.markRejected()
        assertEquals(" ..", h.nextSuffix())
    }
    @Test fun trackerNeedsObservedTickAndHasGrace() {
        val t = TimerTracker(graceMs = 1000)
        t.onReading(7, 0); assertFalse(t.isActive(100))          // لم يُرصد تناقص بعد
        t.onReading(6, 1000); t.onReading(5, 2000); t.onReading(4, 3000)
        assertTrue(t.isActive(3000))
        val rem = t.remainingMs(3000)!!                            // 00:00 عند 7000 + مهلة 1000 = 8000
        assertTrue("rem=$rem", rem in 4500..5500)
        t.onReading(0, 7000); assertTrue(t.isActive(7000))        // 00:00 ظاهر لكن المهلة باقية
        assertFalse(t.isActive(9500))
    }
    @Test fun newRoundResets() {
        val t = TimerTracker()
        t.onReading(2, 0); t.onReading(1, 1000); t.onReading(0, 2000)
        t.onReading(7, 20000); assertFalse(t.isActive(20100))     // جولة جديدة غير مؤكدة بعد
        t.onReading(6, 21000); assertTrue(t.isActive(21000))
    }
}
