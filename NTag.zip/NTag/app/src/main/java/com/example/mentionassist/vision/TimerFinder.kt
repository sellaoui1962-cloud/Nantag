package com.example.mentionassist.vision

import android.graphics.Bitmap

/**
 * يجد المؤقّت من أيقونة الساعة الرملية (شكلها ثابت مهما تغيّر الوقت أو موضع المؤقّت)،
 * ثم يقرأ الأرقام على يسار الأيقونة بـ OCR على مقطع مكبَّر فقط.
 */
class TimerFinder(private val tpl: TemplateSet, private val detector: TextDetector) {
    data class Reading(val seconds: Int, val icon: Match)

    private val rx = Regex("(\\d{1,2})\\s*[:：;.]\\s*(\\d{2})")
    private var last: Match? = null

    fun parse(text: String): Int? {
        val m = rx.find(text) ?: return null
        val mm = m.groupValues[1].toInt(); val ss = m.groupValues[2].toInt()
        return if (ss > 59 || mm > 59) null else mm * 60 + ss
    }

    suspend fun read(fr: Frame): Reading? {
        val full = intArrayOf(0, 0, fr.w, fr.h)
        val near = last?.let { intArrayOf(it.x - 40, it.y - 40, it.x + 40, it.y + 40) }
        val icon = (near?.let { Matcher.findMulti(fr, tpl, "hourglass", floatArrayOf(1f), it, 1, 0.15f) }
            ?: Matcher.findMulti(fr, tpl, "hourglass", floatArrayOf(1f, 0.85f, 1.2f), full, 3, 0.15f)) ?: run { last = null; return null }
        last = icon
        val x0 = (icon.x - 3.4f * icon.w).toInt().coerceAtLeast(0)
        val x1 = (icon.x - 0.15f * icon.w).toInt()
        val y0 = (icon.y - 0.1f * icon.h).toInt().coerceAtLeast(0)
        val y1 = (icon.y + 1.1f * icon.h).toInt().coerceAtMost(fr.h)
        if (x1 - x0 < 12 || y1 - y0 < 8) return null
        val crop = Bitmap.createBitmap(fr.bmp, x0, y0, x1 - x0, y1 - y0)
        val up = Bitmap.createScaledBitmap(crop, crop.width * 3, crop.height * 3, true)
        crop.recycle()
        val text = try { detector.detect(up).joinToString(" ") { it.text } } finally { up.recycle() }
        val s = parse(text) ?: return null
        return Reading(s, icon)
    }
}
