package com.example.mentionassist.ui

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings as AndroidSettings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.mentionassist.core.AppState
import com.example.mentionassist.core.LogEntry
import com.example.mentionassist.core.Settings
import com.example.mentionassist.service.AssistService
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * N@tag — واجهة هاكر بسيطة: أسود + أخضر نيون واحد + رمادي خافت، وأحمر لزر الإيقاف فقط.
 */
class MainActivity : ComponentActivity() {
    private val BG = Color.parseColor("#000000")
    private val PANEL = Color.parseColor("#07110C")
    private val G = Color.parseColor("#00FF9C")       // اللون الوحيد
    private val DIM = Color.parseColor("#5E8F7A")     // أخضر خافت للنصوص الثانوية
    private val RED = Color.parseColor("#FF3B3B")     // للإيقاف فقط
    private val MONO = Typeface.MONOSPACE

    private lateinit var s: Settings
    private lateinit var root: LinearLayout
    private lateinit var statusTv: TextView
    private lateinit var timerTv: TextView
    private lateinit var confTv: TextView
    private lateinit var startBtn: TextView
    private lateinit var setupBox: LinearLayout
    private lateinit var micsTv: TextView
    private lateinit var logBox: LinearLayout
    private lateinit var cursorTv: TextView
    private lateinit var dbgTv: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var cursorOn = true

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun box(fill: Int, stroke: Int?, r: Int = 6) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(r).toFloat(); if (stroke != null) setStroke(dp(1), stroke)
    }
    private fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { setMargins(0, dp(top), 0, dp(bottom)) }
    private fun tv(t: String, size: Float = 13f, color: Int = G, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); typeface = if (bold) Typeface.create(MONO, Typeface.BOLD) else MONO
        layoutDirection = View.LAYOUT_DIRECTION_LTR; textDirection = View.TEXT_DIRECTION_LTR
    }
    private fun panel(title: String? = null): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = box(PANEL, DIM); setPadding(dp(14), dp(12), dp(14), dp(14))
        }
        if (title != null) c.addView(tv("┌─ $title", 12f, DIM, true), lp(bottom = 8))
        root.addView(c, lp(bottom = 12))
        return c
    }
    private fun btn(t: String, color: Int = G, filled: Boolean = false, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 15f; typeface = Typeface.create(MONO, Typeface.BOLD); gravity = Gravity.CENTER
        setTextColor(if (filled) BG else color); background = box(if (filled) color else BG, color)
        isClickable = true; setOnClickListener { onClick() }
    }
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun slider(parent: LinearLayout, label: String, min: Int, max: Int, get: () -> Int, set: (Int) -> Unit) {
        val lbl = tv("$label: ${get()}", 12f, DIM)
        val sb = SeekBar(this).apply {
            this.max = max - min; progress = get() - min
            progressTintList = ColorStateList.valueOf(G); thumbTintList = ColorStateList.valueOf(G)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(b: SeekBar?, p: Int, u: Boolean) { set(p + min); lbl.text = "$label: ${p + min}" }
                override fun onStartTrackingTouch(b: SeekBar?) {}
                override fun onStopTrackingTouch(b: SeekBar?) {}
            })
        }
        parent.addView(lbl, lp(top = 8)); parent.addView(sb, lp())
    }
    private fun switchRow(parent: LinearLayout, label: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        parent.addView(Switch(this).apply {
            text = label; setTextColor(G); typeface = MONO; textSize = 13f; isChecked = get()
            thumbTintList = ColorStateList.valueOf(G); trackTintList = ColorStateList.valueOf(DIM)
            setOnCheckedChangeListener { _, c -> set(c) }
        }, lp(top = 8))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        s = Settings(this)
        window.statusBarColor = BG; window.navigationBarColor = BG
        val sv = ScrollView(this).apply { setBackgroundColor(BG); isFillViewport = true }
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(28), dp(16), dp(36)) }
        sv.addView(root); setContentView(sv)

        // ---------- الرأس
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("N@tag", 34f, G, true))
        cursorTv = tv("_", 34f, G, true); head.addView(cursorTv)
        root.addView(head)
        root.addView(tv("> quick mention, last second", 12f, DIM), lp(bottom = 16))

        // ---------- الحالة والمؤقّت
        val st = panel("status")
        statusTv = tv("[ OFFLINE ]", 14f, DIM, true); st.addView(statusTv)
        timerTv = tv("--", 52f, G, true).apply { gravity = Gravity.CENTER }
        st.addView(timerTv, lp(top = 10))
        st.addView(tv("time to deadline", 11f, DIM).apply { gravity = Gravity.CENTER }, lp(w = ViewGroup.LayoutParams.MATCH_PARENT))
        confTv = tv("sync: 0%", 11f, DIM).apply { gravity = Gravity.CENTER }; st.addView(confTv, lp(top = 4))
        micsTv = tv("mics: 0", 11f, DIM).apply { gravity = Gravity.CENTER }; st.addView(micsTv)
        dbgTv = tv("debug: -", 10f, DIM).apply { gravity = Gravity.CENTER }; st.addView(dbgTv, lp(top = 4))

        // ---------- التشغيل
        startBtn = btn("[ START ]", G, true) { toggle() }
        root.addView(startBtn, lp(h = dp(58), bottom = 8))
        root.addView(btn("■ KILL", RED) { AssistService.instance?.killSwitch() ?: run { AppState.running.value = false } }, lp(h = dp(44), bottom = 14))

        // ---------- الإعداد (يظهر فقط إن لم تُفعَّل الخدمة)
        setupBox = panel("setup")

        // ---------- طريقة الاستخدام
        val how = panel("usage")
        how.addView(tv("1. START ثم افتح اللعبة\n2. اضغط مطولًا على دائرتك لاستثنائها\n3. أثناء الجولة اضغط دائرة لاعب ← @ ← إرسال تلقائي", 12f, G))

        // ---------- الإعدادات
        val cfg = panel()
        val cfgBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val cfgToggle = tv("[+] config", 14f, DIM, true)
        cfgToggle.setOnClickListener {
            val show = cfgBody.visibility != View.VISIBLE
            cfgBody.visibility = if (show) View.VISIBLE else View.GONE
            cfgToggle.text = if (show) "[-] config" else "[+] config"
        }
        cfg.addView(cfgToggle); cfg.addView(cfgBody)
        slider(cfgBody, "ring alpha", 20, 255, { s.alpha }, { s.alpha = it })
        slider(cfgBody, "ring size %", 50, 160, { s.sizePct }, { s.sizePct = it })
        switchRow(cfgBody, "auto-send", { s.autoSend }, { s.autoSend = it })
        switchRow(cfgBody, "only during active round", { s.requireActiveRound }, { s.requireActiveRound = it })
        slider(cfgBody, "grace after 00:00 (ms)", 0, 2500, { s.graceMs }, { s.graceMs = it })
        slider(cfgBody, "safety margin (ms)", 0, 1500, { s.safetyMs }, { s.safetyMs = it })
        slider(cfgBody, "send earlier (ms)", 0, 1500, { s.sendAtRemainingMs }, { s.sendAtRemainingMs = it })
        slider(cfgBody, "capture delay (ms)", 0, 500, { s.captureDelayMs }, { s.captureDelayMs = it })
        cfgBody.addView(tv("game package contains (blank = any)", 12f, DIM), lp(top = 10))
        cfgBody.addView(EditText(this).apply {
            setText(s.gamePkgContains); setSingleLine(); setTextColor(G); typeface = MONO; background = box(BG, DIM); setPadding(dp(12), dp(8), dp(12), dp(8))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) { s.gamePkgContains = e.toString() }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            })
        }, lp(top = 4))
        cfgBody.addView(btn("reset my mic", DIM) { AssistService.instance?.clearMySeat() ?: toast("enable the service first") }, lp(h = dp(42), top = 10))
        cfgBody.addView(btn("reset dot toggle", DIM) { AssistService.instance?.resetHistory(); toast("ok") }, lp(h = dp(42), top = 8))

        // ---------- السجل
        logBox = panel("log")

        refreshSetup(false)
        renderLog(emptyList())
        blink()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    combine(AppState.status, AppState.running, AppState.serviceConnected) { a, b, c -> Triple(a, b, c) }.collect { (stText, run, conn) ->
                        statusTv.text = when { !conn -> "[ SERVICE OFF ]"; run -> "[ ● RUNNING ] $stText"; else -> "[ IDLE ] $stText" }
                        statusTv.setTextColor(if (conn && run) G else DIM)
                        startBtn.text = if (run) "[ STOP ]" else "[ START ]"
                        refreshSetup(conn)
                    }
                }
                launch {
                    combine(AppState.timerText, AppState.timerConfidence) { t, c -> t to c }.collect { (t, c) ->
                        timerTv.text = t; confTv.text = "sync: ${(c * 100).toInt()}%"
                    }
                }
                launch { AppState.seats.collect { micsTv.text = "mics: ${it.size}" } }
                launch { AppState.log.collect { renderLog(it) } }
                launch {
                    combine(AppState.debug, AppState.foregroundPkg) { d, p -> d to p }.collect { (d, p) ->
                        dbgTv.text = "app: ${p.ifEmpty { "?" }}\n$d"
                    }
                }
            }
        }
    }

    override fun onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy() }

    private fun blink() {
        handler.postDelayed({
            cursorOn = !cursorOn
            cursorTv.setTextColor(if (cursorOn) G else BG)
            blink()
        }, 530)
    }

    private fun refreshSetup(connected: Boolean) {
        setupBox.removeAllViews()
        setupBox.addView(tv("┌─ setup", 12f, DIM, true), lp(bottom = 8))
        setupBox.addView(tv(if (connected) "[x] accessibility service" else "[ ] accessibility service", 13f, if (connected) G else DIM, true))
        if (!connected) {
            setupBox.addView(tv("فعّل N@tag من إعدادات الوصول. إن ظهر «إعداد مقيّد»: معلومات التطبيق ← ⋮ ← السماح بالإعدادات المقيّدة.", 12f, DIM), lp(top = 6))
            setupBox.addView(btn("open accessibility", G) { startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS)) }, lp(h = dp(44), top = 10))
        }
        setupBox.visibility = if (connected) View.GONE else View.VISIBLE
    }

    private fun toggle() {
        if (!AppState.serviceConnected.value) { toast("enable the service first"); startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS)); return }
        AppState.running.value = !AppState.running.value
        if (!AppState.running.value) AppState.status.value = "متوقف"
    }

    private fun renderLog(l: List<LogEntry>) {
        logBox.removeAllViews()
        logBox.addView(tv("┌─ log", 12f, DIM, true), lp(bottom = 8))
        if (l.isEmpty()) { logBox.addView(tv("> waiting...", 12f, DIM)); return }
        val f = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        l.take(8).forEach {
            val bad = it.status.contains("توقّف") || it.status.contains("رُفض") || it.status.contains("فشل") || it.status.contains("لم ")
            val good = it.status.contains("تم التحقق")
            logBox.addView(tv("> ${f.format(Date(it.timeMs))} ${it.text}", 12f, G), lp(top = 6))
            logBox.addView(tv("  ${if (good) "[ok]" else if (bad) "[!!]" else "[..]"} ${it.status}", 11f, if (bad) RED else DIM))
        }
    }
}
