package com.example.mentionassist.vision

/**
 * قناع كلمة «مقفل» (أبيض رفيع) تحت مقعد المايك، بإحداثيات نسبية لمركز المقعد على إطار عرضه 720.
 * اختُبر على كل لقطاتك وفيديو الشاشة: المقاعد المقفلة 1.00 والبقية ≤ 0.61.
 */
object LockMask {
    private const val RAW = "-12,82;-12,83;-11,83;-12,84;-11,84;-4,84;4,84;6,84;7,84;-12,85;-4,85;4,85;-12,86;-11,86;-12,87;-11,87;-12,88;-11,88;-4,88;-3,88;6,88;-12,89;-11,89;-5,89;-4,89;-3,89;-2,89;4,89;5,89;6,89;7,89;16,89;17,89;-11,90;-6,90;-5,90;-2,90;3,90;4,90;7,90;15,90;16,90;17,90;-11,91;-6,91;3,91;8,91;14,91;18,91;-11,92;3,92;8,92;14,92;18,92;-11,93;-6,93;3,93;8,93;13,93;14,93;18,93;19,93;-11,94;-10,94;-9,94;-8,94;-7,94;-6,94;-5,94;-4,94;-3,94;-2,94;-1,94;0,94;1,94;2,94;3,94;4,94;5,94;6,94;7,94;8,94;9,94;10,94;11,94;12,94;13,94;14,94;15,94;16,94;17,94;18,94;19,94;-10,95;-9,95;-8,95;-7,95;-6,95;-5,95;-3,95;-2,95;-1,95;0,95;1,95;2,95;3,95;4,95;7,95;8,95;9,95;10,95;11,95;15,95;16,95;17,95;18,95"
    val xs: IntArray
    val ys: IntArray
    init {
        val p = RAW.split(";").map { it.split(",") }
        xs = IntArray(p.size) { p[it][0].toInt() }
        ys = IntArray(p.size) { p[it][1].toInt() }
    }

    private fun white(px: Int): Boolean {
        val r = (px shr 16) and 255; val g = (px shr 8) and 255; val b = px and 255
        val lum = (r * 299 + g * 587 + b * 114) / 1000
        return lum >= 195 && (maxOf(r, g, b) - minOf(r, g, b)) <= 70
    }

    /** أعلى نسبة تطابق (0..1) للقناع حول (cx, cy + dyBase) مع بحث ±5 بكسل. */
    fun score(fr: Frame, cx: Float, cy: Float, dyBase: Float = 0f): Float {
        var best = 0
        for (dy in -5..5) for (dx in -5..5) {
            var c = 0
            for (i in xs.indices) {
                val x = (cx + xs[i] + dx).toInt(); val y = (cy + dyBase + ys[i] + dy).toInt()
                if (x in 0 until fr.w && y in 0 until fr.h && white(fr.pix[y * fr.w + x])) c++
            }
            if (c > best) best = c
        }
        return best.toFloat() / xs.size
    }
}
