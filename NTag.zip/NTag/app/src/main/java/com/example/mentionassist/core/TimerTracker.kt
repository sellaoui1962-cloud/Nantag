package com.example.mentionassist.core

/**
 * يقدّر آخر لحظة مقبولة للإرسال اعتمادًا على ساعة النظام ويصحّحها بكل قراءة جديدة.
 * من الفيديو: يبقى 00:00 ظاهرًا ≈ ثانية أخرى قبل أن تُقبل الرسالة آخر مرة، لذلك
 * الموعد النهائي = لحظة ظهور 00:00 + graceMs (قابلة للمعايرة).
 * الجولة لا تُعدّ نشطة إلا بعد رصد تناقص فعلي في الأرقام (لتفادي قراءة أوقات قديمة في الدردشة).
 */
class TimerTracker(private val staleMs: Long = 2500, var graceMs: Long = 1000) {
    private var lastSec: Int? = null
    private var lastAt = 0L
    private var lastSeenAt = 0L
    private var confirmed = false
    private val ends = ArrayList<Long>()
    private var uncertainty = 1000L

    @Synchronized
    fun onReading(sec: Int, atMs: Long) {
        val prev = lastSec
        when {
            prev == null || sec > prev -> {
                ends.clear(); confirmed = false
                ends.add(atMs + sec * 1000L - 500); uncertainty = 1000
            }
            sec < prev -> {
                ends.add((lastAt + atMs) / 2 + sec * 1000L)
                uncertainty = (atMs - lastAt) / 2; confirmed = true
            }
        }
        lastSec = sec; lastAt = atMs; lastSeenAt = atMs
    }

    @Synchronized fun displaySeconds(): Int? = lastSec

    /** ms حتى الموعد النهائي (00:00 + المهلة). */
    @Synchronized
    fun remainingMs(now: Long): Long? {
        if (ends.isEmpty() || lastSec == null) return null
        val sorted = ends.sorted()
        return (sorted[sorted.size / 2] + graceMs - now).coerceAtLeast(0)
    }

    @Synchronized
    fun isActive(now: Long): Boolean {
        if (lastSec == null || !confirmed || now - lastSeenAt > staleMs) return false
        return (remainingMs(now) ?: 0) > 0
    }

    @Synchronized
    fun confidence(now: Long): Float {
        if (lastSec == null || now - lastSeenAt > staleMs) return 0f
        val n = minOf(ends.size, 4) / 4f
        val u = 1f - (uncertainty.coerceAtMost(1000) / 1500f)
        return (0.25f + 0.75f * n) * u * (if (confirmed) 1f else 0.5f)
    }

    @Synchronized fun reset() { lastSec = null; ends.clear(); lastSeenAt = 0; confirmed = false }
}
