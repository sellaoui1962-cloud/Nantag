package com.example.mentionassist.core

import android.content.Context
import android.graphics.Color

class Settings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("mention_assist", Context.MODE_PRIVATE)
    private fun int(k: String, d: Int) = sp.getInt(k, d)
    private fun put(k: String, v: Int) = sp.edit().putInt(k, v).apply()

    // --- مظهر الدوائر ---
    var alpha: Int get() = int("alpha", 110); set(v) = put("alpha", v.coerceIn(20, 255))
    var sizePct: Int get() = int("sizePct", 100); set(v) = put("sizePct", v.coerceIn(50, 160))

    // --- معايرة الهندسة (نسب من عرض الشاشة ×1000، ومن الارتفاع ×1000 للحدود الرأسية) ---
    var colStart: Int get() = int("colStart", 100); set(v) = put("colStart", v)      // 0.100 W
    var colPitch: Int get() = int("colPitch", 200); set(v) = put("colPitch", v)      // 0.200 W
    var colCount: Int get() = int("colCount", 5); set(v) = put("colCount", v)
    var circleOffsetY: Int get() = int("offY", 125); set(v) = put("offY", v)         // مركز الدائرة فوق منتصف الاسم
    var radius: Int get() = int("radius", 70); set(v) = put("radius", v)             // 0.070 W
    var yMin: Int get() = int("yMin", 190); set(v) = put("yMin", v)                  // 0.190 H
    var yMax: Int get() = int("yMax", 545); set(v) = put("yMax", v)                  // 0.545 H

    // --- الإرسال والتوقيت ---
    var autoSend: Boolean get() = int("autoSend", 1) == 1; set(v) = put("autoSend", if (v) 1 else 0)
    var sendAtRemaining: Boolean get() = int("sendAtRem", 0) == 1; set(v) = put("sendAtRem", if (v) 1 else 0)
    var sendAtRemainingMs: Int get() = int("sendAtRemMs", 0); set(v) = put("sendAtRemMs", v)
    var sendLatencyMs: Int get() = int("sendLatMs", 350); set(v) = put("sendLatMs", v)
    var safetyMs: Int get() = int("safetyMs", 150); set(v) = put("safetyMs", v)
    var captureDelayMs: Int get() = int("capDelay", 120); set(v) = put("capDelay", v)
    var requireActiveRound: Boolean get() = int("reqRound", 0) == 1; set(v) = put("reqRound", if (v) 1 else 0)
    var minOcrConf: Int get() = int("minConf", 60); set(v) = put("minConf", v)       // %

    var mode: Int get() = int("mode", 0); set(v) = put("mode", v)
    var bubbleX: Int get() = int("bubX", 20); set(v) = put("bubX", v)
    var bubbleY: Int get() = int("bubY", 300); set(v) = put("bubY", v)

    var graceMs: Int get() = int("graceMs", 1000); set(v) = put("graceMs", v)   // مهلة بعد ظهور 00:00 (قِيست ≈1 ث من الفيديو)
    var mySig: String
        get() = sp.getString("mySig", "") ?: ""
        set(v) = sp.edit().putString("mySig", v).apply()

    // --- نقاط معايرة يدوية (بكسل شاشة، -1 = غير مضبوطة) ---
    var chatOpenX: Int get() = int("coX", -1); set(v) = put("coX", v)
    var chatOpenY: Int get() = int("coY", -1); set(v) = put("coY", v)
    var sendX: Int get() = int("sX", -1); set(v) = put("sX", v)
    var sendY: Int get() = int("sY", -1); set(v) = put("sY", v)

    var gamePkgContains: String
        get() = sp.getString("pkg", "") ?: ""
        set(v) = sp.edit().putString("pkg", v.trim()).apply()

    // لون واحد فقط لكل الدوائر (واجهة هاكر: أخضر نيون)
    val accent: Int = Color.parseColor("#00FF9C")
    fun colorFor(name: String, index: Int): Int = accent
}
