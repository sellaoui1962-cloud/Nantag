package com.example.mentionassist.service

import android.os.SystemClock
import com.example.mentionassist.core.AppState
import com.example.mentionassist.core.MentionHistory
import com.example.mentionassist.core.Seat
import com.example.mentionassist.core.Settings
import com.example.mentionassist.core.TimerTracker
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * تسلسل المنشن كما في اللعبة (من صورك/فيديوهاتك):
 *   ضغط مايك اللاعب → يظهر ملفه → ضغط زر @ → تُكتب المنشنة تلقائيًا في الحقل
 *   → نضيف " ." أو " .." (تتبدّل) → ننتظر آخر لحظة مقبولة → ضغط زر الإرسال الأخضر → تحقق.
 */
class MentionEngine(private val svc: AssistService, private val s: Settings, private val tracker: TimerTracker) {
    val history = MentionHistory()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null
    private var confirm: CompletableDeferred<Unit>? = null

    private val atRegion = floatArrayOf(0f, 0.35f, 0.28f, 0.95f)       // يسار أعلى ملف اللاعب
    private val sendRegion = floatArrayOf(0f, 0.30f, 0.40f, 0.90f)     // يسار شريط الكتابة
    private fun now() = SystemClock.elapsedRealtime()
    private fun log(t: String, st: String) = AppState.addLog(t, st)
    private fun roundOk() = !s.requireActiveRound || tracker.isActive(now())

    fun onSeatTapped(seat: Seat) {
        if (!AppState.running.value) return
        if (job?.isActive == true) { log(seat.name, "مشغول بعملية سابقة"); return }
        AppState.selectedKey.value = seat.key
        job = scope.launch { run(seat) }
    }

    fun confirmSend() { confirm?.complete(Unit) }

    fun killSwitch() {
        job?.cancel(); job = null
        confirm?.cancel(); confirm = null
        AppState.pendingConfirm.value = null; AppState.selectedKey.value = null
        AppState.busy.value = false; AppState.running.value = false
        AppState.status.value = "تم الإيقاف الفوري"; log("—", "إيقاف فوري")
    }

    private fun fail(seat: Seat, why: String) { log(seat.name, "توقّف: $why"); AppState.status.value = "قيد التشغيل" }

    private suspend fun run(seat: Seat) {
        if (!roundOk()) { log(seat.name, "رُفض: لا توجد جولة نشطة"); AppState.selectedKey.value = null; return }
        AppState.busy.value = true
        svc.overlay.clearSeats()                     // نزيل نوافذ الدوائر كي لا تحجب ضغطات الأتمتة
        try {
            AppState.status.value = "فتح ملف ${seat.name}"
            if (!svc.tapPx(seat.cx.toInt(), seat.cy.toInt())) return fail(seat, "فشلت ضغطة المايك")

            val at = svc.awaitMatch("at", atRegion, floatArrayOf(0.9f, 1f, 1.1f, 1.2f), 0.10f, 2500)
                ?: return fail(seat, "لم يظهر زر @ (لم يُفتح ملف اللاعب؟)")
            svc.tapPx(at.x, at.y)

            val send = svc.awaitMatch("send", sendRegion, floatArrayOf(1f), 0.09f, 3000)
                ?: return fail(seat, "لم يظهر زر الإرسال بعد @")
            delay(150)

            val suffix = history.nextSuffix()
            if (!svc.appendSuffix(suffix)) return fail(seat, "تعذّر إضافة النقطة (الحقل غير متاح لخدمة الوصول)")
            delay(120)
            val txt = svc.inputText()
            if (txt != null && !txt.endsWith(suffix)) return fail(seat, "النقطة لم تُضف، لن أرسل")
            log(txt ?: "(نص الحقل غير مقروء)", "جُهّزت")

            // آخر لحظة مقبولة: نرسل حين يتبقى (زمن الضغط + هامش أمان + تقديم إضافي) قبل الموعد النهائي
            val lead = s.sendLatencyMs + s.safetyMs + s.sendAtRemainingMs
            while (true) {
                if (!roundOk()) return fail(seat, "انتهت الجولة قبل الإرسال")
                val rem = tracker.remainingMs(now())
                if (rem != null && rem <= lead) break
                delay(if (rem == null) 50 else minOf(40L, (rem - lead).coerceAtLeast(5)))
            }
            if (!s.autoSend) {
                val d = CompletableDeferred<Unit>(); confirm = d
                AppState.pendingConfirm.value = txt ?: "منشن"
                while (!d.isCompleted) { if (!roundOk()) { AppState.pendingConfirm.value = null; return fail(seat, "انتهت الجولة قبل التأكيد") }; delay(30) }
                AppState.pendingConfirm.value = null
            }

            val t0 = now()
            svc.tapPx(send.x, send.y)
            val tapMs = now() - t0
            val remAtTap = tracker.remainingMs(now()) ?: 0
            val sent = svc.awaitAbsent("send", sendRegion, 0.12f, 450, 1500)

            s.sendLatencyMs = (s.sendLatencyMs * 0.7 + tapMs * 0.3).toInt().coerceIn(60, 1200)
            if (sent) {
                history.commit(); log(txt ?: "منشن", "أُرسلت (تم التحقق)")
                // تعلّم: إن كان الإرسال متأخرًا جدًا ازدد أمانًا، وإلا اقترب من الحافة تدريجيًا
                s.safetyMs = if (remAtTap <= 0) (s.safetyMs + 80).coerceAtMost(1200) else (s.safetyMs - 15).coerceAtLeast(100)
            } else {
                history.markRejected()
                if (remAtTap <= 0) s.safetyMs = (s.safetyMs + 150).coerceAtMost(1200)
                log(txt ?: "منشن", "لم يتأكد الإرسال (رُفضت أو متأخرة) — سأبدّل شكل النقطة")
            }
        } finally {
            AppState.busy.value = false
            AppState.selectedKey.value = null
            if (AppState.running.value) AppState.status.value = "قيد التشغيل"
        }
    }
}
