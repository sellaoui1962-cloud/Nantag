package com.example.mentionassist.overlay

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.example.mentionassist.core.Seat
import com.example.mentionassist.core.Settings

private val NEON = Color.parseColor("#00FF9C")

/** مقعد على الشاشة: حلقة (نمط الدوائر) أو رقم عائم صغير (نمط الأرقام). */
class CircleView(ctx: Context) : View(ctx) {
    var ringColor = NEON
    var alphaVal = 110
    var number = 0
    var numbersMode = false
        set(v) { field = v; invalidate() }
    var selectedState = false
        set(v) { field = v; if (v) startPulse() else stopPulse(); invalidate() }
    private var pulse = 0f
    private var anim: ValueAnimator? = null
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); textAlign = Paint.Align.CENTER }

    private fun startPulse() {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
            addUpdateListener { pulse = it.animatedValue as Float; invalidate() }; start()
        }
    }
    private fun stopPulse() { anim?.cancel(); anim = null; pulse = 0f }
    override fun onDetachedFromWindow() { stopPulse(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val base = minOf(width, height) / 2f
        if (numbersMode) {
            val sw = base * 0.10f
            fill.color = Color.BLACK; fill.alpha = if (selectedState) 235 else 190
            c.drawCircle(cx, cy, base - sw, fill)
            ring.strokeWidth = sw; ring.color = ringColor
            ring.alpha = if (selectedState) (140 + 115 * pulse).toInt() else 255
            c.drawCircle(cx, cy, base - sw, ring)
            txt.color = ringColor; txt.textSize = base * (if (number >= 10) 0.95f else 1.15f)
            c.drawText(number.toString(), cx, cy - (txt.ascent() + txt.descent()) / 2f, txt)
            return
        }
        val sw = base * (if (selectedState) 0.16f else 0.10f)
        val r = base - sw
        ring.strokeWidth = sw
        ring.color = ringColor
        ring.alpha = if (selectedState) (alphaVal + (255 - alphaVal) * (0.4f + 0.6f * pulse)).toInt() else alphaVal
        c.drawCircle(cx, cy, r, ring)
        if (selectedState) {
            fill.color = ringColor; fill.alpha = (30 + 40 * pulse).toInt()
            c.drawCircle(cx, cy, r, fill)
        }
    }
}

class OverlayManager(private val svc: AccessibilityService, private val s: Settings) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val d = svc.resources.displayMetrics.density
    private fun px(v: Int) = (v * d).toInt()
    private val circles = HashMap<String, CircleView>()
    private val geo = HashMap<String, IntArray>()
    private val seatByKey = HashMap<String, Seat>()
    private var onTapCb: ((Seat) -> Unit)? = null
    private var onLongCb: ((Seat) -> Unit)? = null

    private fun lp(x: Int, y: Int, w: Int, h: Int, touchable: Boolean) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    /** اللمس يُلتقط من DOWN/UP مباشرة، والنافذة لا تتحرك إلا إذا تغيّر موضع المقعد فعلًا. */
    private fun attachTouch(v: CircleView, key: String) {
        val h = Handler(Looper.getMainLooper())
        var downAt = 0L
        var longFired = false
        val longRun = Runnable { longFired = true; seatByKey[key]?.let { onLongCb?.invoke(it) } }
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downAt = SystemClock.uptimeMillis(); longFired = false; h.postDelayed(longRun, 600) }
                MotionEvent.ACTION_UP -> { h.removeCallbacks(longRun); if (!longFired) seatByKey[key]?.let { onTapCb?.invoke(it) } }
                MotionEvent.ACTION_CANCEL -> {
                    h.removeCallbacks(longRun)
                    if (!longFired && SystemClock.uptimeMillis() - downAt < 400) seatByKey[key]?.let { onTapCb?.invoke(it) }
                }
            }
            true
        }
    }

    fun renderSeats(seats: List<Seat>, selectedKey: String?, numbers: Boolean, onTap: (Seat) -> Unit, onLong: (Seat) -> Unit) {
        onTapCb = onTap; onLongCb = onLong
        val keep = seats.map { it.key }.toSet()
        circles.keys.filter { it !in keep }.forEach { k -> circles.remove(k)?.let { runCatching { wm.removeView(it) } }; geo.remove(k); seatByKey.remove(k) }
        seats.forEachIndexed { i, seat ->
            seatByKey[seat.key] = seat
            val size = if (numbers) px(34) else (2 * (seat.r + seat.r * 0.25f)).toInt()
            val x = (seat.cx - size / 2f).toInt(); val y = (seat.cy - size / 2f).toInt()
            var created = false
            val v = circles.getOrPut(seat.key) {
                created = true
                CircleView(svc).also { cv ->
                    wm.addView(cv, lp(x, y, size, size, true))
                    geo[seat.key] = intArrayOf(x, y, size)
                    attachTouch(cv, seat.key)
                }
            }
            val g = geo[seat.key]
            if (!created && (g == null || Math.abs(g[0] - x) > 4 || Math.abs(g[1] - y) > 4 || Math.abs(g[2] - size) > 4)) {
                runCatching { wm.updateViewLayout(v, lp(x, y, size, size, true)) }
                geo[seat.key] = intArrayOf(x, y, size)
            }
            val col = s.colorFor(seat.key, i)
            if (created || v.ringColor != col || v.alphaVal != s.alpha || v.number != seat.num) {
                v.ringColor = col; v.alphaVal = s.alpha; v.number = seat.num; v.invalidate()
            }
            if (v.numbersMode != numbers) v.numbersMode = numbers
            if (v.selectedState != (seat.key == selectedKey)) v.selectedState = seat.key == selectedKey
        }
    }

    fun clearSeats() {
        circles.values.forEach { runCatching { wm.removeView(it) } }
        circles.clear(); geo.clear(); seatByKey.clear()
    }

    // ------------------------------------------------------------------ الزر العائم
    private var bubbleRoot: LinearLayout? = null
    private var bubbleBtn: TextView? = null
    private var runBtn: TextView? = null
    private var modeCircBtn: TextView? = null
    private var modeNumBtn: TextView? = null
    private var okBtn: TextView? = null
    private var statusTv: TextView? = null
    private var controls: LinearLayout? = null
    private val bubbleHandler = Handler(Looper.getMainLooper())
    private val collapse = Runnable { controls?.visibility = View.GONE }

    private fun chip(t: String, color: Int = NEON): TextView = TextView(svc).apply {
        text = t; setTextColor(color); textSize = 15f; typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        gravity = Gravity.CENTER
        background = GradientDrawable().apply { setColor(Color.BLACK); setStroke(px(1), color); cornerRadius = px(8).toFloat() }
        layoutParams = LinearLayout.LayoutParams(px(38), px(38)).apply { marginStart = px(6) }
    }

    fun showBubble(onRun: () -> Unit, onMode: (Int) -> Unit, onConfirm: () -> Unit, onHide: () -> Unit) {
        if (bubbleRoot != null) return
        val root = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val b = TextView(svc).apply {
            text = "N@"; textSize = 14f; typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); gravity = Gravity.CENTER
            setTextColor(NEON)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.BLACK); setStroke(px(2), NEON) }
        }
        root.addView(b, LinearLayout.LayoutParams(px(46), px(46)))
        val ctl = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE }
        val run = chip("▶").also { it.setOnClickListener { onRun(); scheduleCollapse() } }
        val mc = chip("◯").also { it.setOnClickListener { onMode(0); scheduleCollapse() } }
        val mn = chip("#").also { it.setOnClickListener { onMode(1); scheduleCollapse() } }
        val ok = chip("✓").also { it.visibility = View.GONE; it.setOnClickListener { onConfirm() } }
        val hide = chip("✕", Color.parseColor("#FF3B3B")).also { it.setOnClickListener { onHide() } }
        val st = TextView(svc).apply {
            setTextColor(NEON); typeface = Typeface.MONOSPACE; textSize = 11f; setPadding(px(6), px(2), px(6), px(2))
            background = GradientDrawable().apply { setColor(Color.argb(190, 0, 0, 0)); cornerRadius = px(6).toFloat() }
        }
        ctl.addView(run); ctl.addView(mc); ctl.addView(mn); ctl.addView(ok); ctl.addView(hide)
        ctl.addView(st, LinearLayout.LayoutParams(-2, -2).apply { marginStart = px(6) })
        root.addView(ctl)

        val params = lp(s.bubbleX, s.bubbleY, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, true)
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = params.x; oy = params.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - sx) > px(8) || Math.abs(e.rawY - sy) > px(8)) moved = true
                    if (moved) { params.x = ox + (e.rawX - sx).toInt(); params.y = oy + (e.rawY - sy).toInt(); runCatching { wm.updateViewLayout(root, params) } }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) { s.bubbleX = params.x; s.bubbleY = params.y }
                    else { ctl.visibility = if (ctl.visibility == View.VISIBLE) View.GONE else View.VISIBLE; scheduleCollapse() }
                }
            }
            true
        }
        wm.addView(root, params)
        bubbleRoot = root; bubbleBtn = b; runBtn = run; modeCircBtn = mc; modeNumBtn = mn; okBtn = ok; statusTv = st; controls = ctl
    }

    private fun scheduleCollapse() { bubbleHandler.removeCallbacks(collapse); bubbleHandler.postDelayed(collapse, 5000) }

    fun updateBubble(running: Boolean, mode: Int, status: String, confirmVisible: Boolean) {
        val b = bubbleBtn ?: return
        (b.background as GradientDrawable).setColor(if (running) NEON else Color.BLACK)
        b.setTextColor(if (running) Color.BLACK else NEON)
        runBtn?.text = if (running) "■" else "▶"
        runBtn?.setTextColor(if (running) Color.parseColor("#FF3B3B") else NEON)
        fun sel(v: TextView?, on: Boolean) { v?.setTextColor(if (on) Color.BLACK else NEON); (v?.background as? GradientDrawable)?.setColor(if (on) NEON else Color.BLACK) }
        sel(modeCircBtn, mode == 0); sel(modeNumBtn, mode == 1)
        statusTv?.text = status
        okBtn?.visibility = if (confirmVisible) View.VISIBLE else View.GONE
        if (confirmVisible) controls?.visibility = View.VISIBLE
    }

    fun hideBubble() {
        bubbleHandler.removeCallbacks(collapse)
        bubbleRoot?.let { runCatching { wm.removeView(it) } }
        bubbleRoot = null; bubbleBtn = null; runBtn = null; modeCircBtn = null; modeNumBtn = null; okBtn = null; statusTv = null; controls = null
    }

    /** يلتقط ضغطة واحدة على الشاشة لحفظ إحداثيات (معايرة يدوية). */
    fun pickPoint(hint: String, onPicked: (Int, Int) -> Unit) {
        val v = object : View(svc) {
            override fun onTouchEvent(e: MotionEvent): Boolean {
                if (e.action == MotionEvent.ACTION_DOWN) {
                    val x = e.rawX.toInt(); val y = e.rawY.toInt()
                    runCatching { wm.removeView(this) }; onPicked(x, y)
                }
                return true
            }
        }.apply { setBackgroundColor(Color.argb(70, 255, 255, 0)) }
        wm.addView(v, lp(0, 0, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, true))
        android.widget.Toast.makeText(svc, hint, android.widget.Toast.LENGTH_LONG).show()
    }

    fun removeAll() { clearSeats() }
    fun destroy() { clearSeats(); hideBubble() }
}
