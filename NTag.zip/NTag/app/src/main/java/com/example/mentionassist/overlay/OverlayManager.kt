package com.example.mentionassist.overlay

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.example.mentionassist.core.Seat
import com.example.mentionassist.core.Settings

/** حلقة شفافة حول مايك لاعب. تُرسم داخل نافذة صغيرة بحجم الدائرة فقط، فلا تحجب بقية اللعبة. */
class CircleView(ctx: Context) : View(ctx) {
    var ringColor = Color.CYAN
    var alphaVal = 110
    var selectedState = false
        set(v) { field = v; if (v) startPulse() else stopPulse(); invalidate() }
    private var pulse = 0f
    private var anim: ValueAnimator? = null
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    private fun startPulse() {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
            addUpdateListener { pulse = it.animatedValue as Float; invalidate() }; start()
        }
    }
    private fun stopPulse() { anim?.cancel(); anim = null; pulse = 0f }
    override fun onDetachedFromWindow() { stopPulse(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val base = minOf(width, height) / 2f
        val sw = base * (if (selectedState) 0.16f else 0.10f)
        val r = base - sw
        ring.strokeWidth = sw
        ring.color = ringColor
        ring.alpha = if (selectedState) (alphaVal + (255 - alphaVal) * (0.4f + 0.6f * pulse)).toInt() else alphaVal
        c.drawCircle(cx, cy, r, ring)
        if (selectedState) {            // تأثير التحديد: تعبئة خفيفة نابضة
            fill.color = ringColor; fill.alpha = (30 + 40 * pulse).toInt()
            c.drawCircle(cx, cy, r, fill)
        }
    }
}

class OverlayManager(private val svc: AccessibilityService, private val s: Settings) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val circles = HashMap<String, CircleView>()
    private var panel: LinearLayout? = null
    private var statusTv: TextView? = null
    private var confirmBtn: Button? = null
    private var confirmView: TextView? = null

    private fun lp(x: Int, y: Int, w: Int, h: Int, touchable: Boolean) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    fun renderSeats(seats: List<Seat>, selectedKey: String?, onTap: (Seat) -> Unit, onLong: (Seat) -> Unit) {
        val keep = seats.map { it.key }.toSet()
        circles.keys.filter { it !in keep }.forEach { k -> circles.remove(k)?.let { runCatching { wm.removeView(it) } } }
        seats.forEachIndexed { i, seat ->
            val pad = seat.r * 0.25f
            val size = (2 * (seat.r + pad)).toInt()
            val x = (seat.cx - size / 2f).toInt(); val y = (seat.cy - size / 2f).toInt()
            val v = circles.getOrPut(seat.key) {
                CircleView(svc).also { cv ->
                    wm.addView(cv, lp(x, y, size, size, true))
                }
            }
            v.ringColor = s.colorFor(seat.key, i)
            v.alphaVal = s.alpha
            v.selectedState = seat.key == selectedKey
            v.setOnClickListener { onTap(seat) }
            v.setOnLongClickListener { onLong(seat); true }
            runCatching { wm.updateViewLayout(v, lp(x, y, size, size, true)) }
            v.invalidate()
        }
    }

    fun setSeatsVisible(visible: Boolean) {
        circles.values.forEach { it.visibility = if (visible) View.VISIBLE else View.GONE }
    }

    fun clearSeats() {
        circles.values.forEach { runCatching { wm.removeView(it) } }
        circles.clear()
    }

    /** لوحة صغيرة: زر إيقاف فوري دائمًا + زر تأكيد الإرسال + سطر حالة. لا تحتوي نصًا بصيغة mm:ss. */
    fun showPanel(screenH: Int, onStop: () -> Unit, onConfirm: () -> Unit) {
        if (panel != null) return
        val d = svc.resources.displayMetrics.density
        fun px(v: Int) = (v * d).toInt()
        val p = LinearLayout(svc).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.argb(170, 0, 0, 0)); setPadding(px(4), px(2), px(4), px(2))
        }
        val stop = TextView(svc).apply {
            text = "■"; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(200, 30, 30)); gravity = Gravity.CENTER
            textSize = 12f; typeface = Typeface.MONOSPACE; setOnClickListener { onStop() }
        }
        val conf = TextView(svc).apply {
            text = "✓"; setTextColor(Color.BLACK); setBackgroundColor(Color.parseColor("#00FF9C")); gravity = Gravity.CENTER
            textSize = 12f; typeface = Typeface.MONOSPACE; visibility = View.GONE; setOnClickListener { onConfirm() }
        }
        val st = TextView(svc).apply { setTextColor(Color.parseColor("#00FF9C")); typeface = Typeface.MONOSPACE; textSize = 11f; setPadding(px(6), 0, px(2), 0) }
        p.addView(stop, LinearLayout.LayoutParams(px(30), px(22)))
        p.addView(conf, LinearLayout.LayoutParams(px(30), px(22)).apply { marginStart = px(4) })
        p.addView(st)
        panel = p; statusTv = st; confirmBtn = null; confirmView = conf
        wm.addView(p, lp(0, px(2), WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, true)
            .apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL })
    }

    fun setPanelStatus(t: String, confirmVisible: Boolean) {
        statusTv?.text = t
        confirmView?.visibility = if (confirmVisible) View.VISIBLE else View.GONE
    }

    fun hidePanel() { panel?.let { runCatching { wm.removeView(it) } }; panel = null }

    /** يلتقط ضغطة واحدة على الشاشة لحفظ إحداثيات (زر فتح الدردشة / زر الإرسال). */
    fun pickPoint(hint: String, onPicked: (Int, Int) -> Unit) {
        val v = object : View(svc) {
            override fun onTouchEvent(e: MotionEvent): Boolean {
                if (e.action == MotionEvent.ACTION_DOWN) {
                    val x = e.rawX.toInt(); val y = e.rawY.toInt()
                    runCatching { wm.removeView(this) }; onPicked(x, y)
                }
                return true
            }
        }.apply { setBackgroundColor(Color.argb(70, 255, 255, 0)) }
        wm.addView(v, lp(0, 0, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, true))
        android.widget.Toast.makeText(svc, hint, android.widget.Toast.LENGTH_LONG).show()
    }

    fun removeAll() { clearSeats(); hidePanel() }
}
