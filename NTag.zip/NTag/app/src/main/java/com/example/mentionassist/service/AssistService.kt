package com.example.mentionassist.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Bundle
import android.os.SystemClock
import android.util.Base64
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.Toast
import com.example.mentionassist.core.AppState
import com.example.mentionassist.core.Seat
import com.example.mentionassist.core.Settings
import com.example.mentionassist.core.TimerTracker
import com.example.mentionassist.overlay.OverlayManager
import com.example.mentionassist.vision.Frame
import com.example.mentionassist.vision.Matcher
import com.example.mentionassist.vision.SeatDetector
import com.example.mentionassist.vision.TemplateSet
import com.example.mentionassist.vision.TextDetector
import com.example.mentionassist.vision.TimerFinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import kotlin.math.max

data class ScreenPt(val x: Int, val y: Int, val score: Float)

class AssistService : AccessibilityService() {
    lateinit var settings: Settings
    lateinit var overlay: OverlayManager
    private lateinit var engine: MentionEngine
    private lateinit var templates: TemplateSet
    private lateinit var timerFinder: TimerFinder
    val tracker = TimerTracker()
    private val detector by lazy { TextDetector() }
    private val seatDetector = SeatDetector()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var loop: Job? = null
    private var misses = 0
    @Volatile private var lastShotErr = 0
    @Volatile private var timerDbg = ""
    private val capLock = Mutex()
    private var lastCapAt = 0L
    private var lastSeats: List<Seat> = emptyList()
    private val frames = MutableSharedFlow<Frame>(extraBufferCapacity = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST)

    override fun onServiceConnected() {
        instance = this
        settings = Settings(this)
        templates = TemplateSet(this)
        timerFinder = TimerFinder(templates, detector)
        overlay = OverlayManager(this, settings)
        engine = MentionEngine(this, settings, tracker)
        AppState.serviceConnected.value = true
        scope.launch { AppState.running.collect { if (it) startLoop() else stopLoop() } }
        AppState.mode.value = settings.mode
        scope.launch { AppState.mode.collect { settings.mode = it; refreshBubble() } }
        scope.launch { AppState.status.collect { refreshBubble() } }
        scope.launch { AppState.pendingConfirm.collect { refreshBubble() } }
        scope.launch { AppState.running.collect { refreshBubble() } }
        scope.launch {
            AppState.bubbleVisible.collect { v ->
                if (v) {
                    overlay.showBubble(
                        onRun = { AppState.running.value = !AppState.running.value; if (!AppState.running.value) AppState.status.value = "متوقف" },
                        onMode = { AppState.mode.value = it },
                        onConfirm = { engine.confirmSend() },
                        onHide = { killSwitch(); AppState.bubbleVisible.value = false }
                    )
                    refreshBubble()
                } else overlay.hideBubble()
            }
        }
    }

    @Volatile private var lastEventPkg = ""
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val p = e?.packageName?.toString() ?: return
        if (p != packageName && !p.startsWith("com.android.systemui")) lastEventPkg = p
    }

    /** الحزمة الأمامية: من النافذة النشطة، ثم قائمة النوافذ، ثم آخر حدث. */
    private fun currentPkg(): String {
        rootInActiveWindow?.packageName?.toString()?.takeIf { it.isNotEmpty() }?.let { return it }
        windows.firstOrNull { it.isActive }?.root?.packageName?.toString()?.takeIf { it.isNotEmpty() }?.let { return it }
        return lastEventPkg
    }

    private fun isGamePkg(pkg: String): Boolean {
        if (pkg == packageName) return false
        if (pkg.startsWith("com.android.systemui") || pkg.contains("launcher", true) || pkg.contains("inputmethod", true)) return false
        val f = settings.gamePkgContains
        return f.isBlank() || pkg.contains(f, ignoreCase = true)
    }
    private fun refreshBubble() {
        val st = AppState.status.value.let { if (it.length > 18) it.take(18) + "…" else it }
        overlay.updateBubble(AppState.running.value, AppState.mode.value, AppState.timerText.value + " " + st, AppState.pendingConfirm.value != null)
    }

    override fun onInterrupt() { killSwitch() }
    override fun onDestroy() {
        instance = null; AppState.serviceConnected.value = false
        scope.coroutineContext[Job]?.cancel(); overlay.destroy(); detector.close(); super.onDestroy()
    }

    fun killSwitch() { engine.killSwitch(); overlay.removeAll() }
    fun resetHistory() = engine.history.reset()
    fun clearMySeat() { settings.mySig = ""; Toast.makeText(this, "أُلغي تحديد مايكك", Toast.LENGTH_SHORT).show() }

    /** ضغطة مطوّلة على دائرة = "هذا مايكي" (تُحفظ بصمة صورته ولا تُرسم عليه دائرة بعدها). */
    fun markMySeat(seat: Seat) {
        val sig = seat.sig ?: return
        settings.mySig = Base64.encodeToString(sig, Base64.NO_WRAP)
        Toast.makeText(this, "تم تحديد مايكك", Toast.LENGTH_SHORT).show()
    }

    private fun isMine(sig: ByteArray): Boolean {
        val s = settings.mySig; if (s.isEmpty()) return false
        val mine = try { Base64.decode(s, Base64.NO_WRAP) } catch (_: Exception) { return false }
        if (mine.size != sig.size) return false
        var d = 0L
        for (i in sig.indices) d += Math.abs((sig[i].toInt() and 255) - (mine[i].toInt() and 255))
        return d / sig.size < 30
    }

    private fun startLoop() {
        if (loop?.isActive == true) return
        AppState.status.value = "قيد التشغيل"
        AppState.bubbleVisible.value = true
        loop = scope.launch { captureLoop() }
    }
    private fun stopLoop() { loop?.cancel(); loop = null; overlay.removeAll(); tracker.reset() }

    private fun keyboardVisible() = windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }

    // ---------- التقاط الشاشة ----------
    private suspend fun captureScreen(): Bitmap? = suspendCancellableCoroutine { cont ->
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                hw?.recycle(); hb.close()
                if (cont.isActive) cont.resume(soft)
            }
            override fun onFailure(errorCode: Int) { lastShotErr = errorCode; if (cont.isActive) cont.resume(null) }
        })
    }

    /** لقطة مصغّرة (عرض 720). النظام يحدّ اللقطات بحوالي 3 في الثانية. */
    private suspend fun grabFrame(): Frame? {
        val shot = capLock.withLock {
            val wait = 350 - (SystemClock.elapsedRealtime() - lastCapAt)
            if (wait > 0) delay(wait)
            val b = captureScreen(); lastCapAt = SystemClock.elapsedRealtime(); b
        } ?: return null
        return withContext(Dispatchers.Default) {
            val h = (720f * shot.height / shot.width).toInt()
            val sc = Bitmap.createScaledBitmap(shot, 720, h, true); shot.recycle()
            val px = IntArray(720 * h); sc.getPixels(px, 0, 720, 0, 0, 720, h)
            Frame(720, h, px, sc)
        }
    }

    private suspend fun captureLoop() {
        while (scope.isActive && AppState.running.value) {
            val t0 = SystemClock.elapsedRealtime()
            val pkg = currentPkg()
            if (pkg.isNotEmpty() && pkg != packageName) AppState.foregroundPkg.value = pkg
            if (isGamePkg(pkg) || pkg.isEmpty()) {
                val fr = grabFrame()
                if (fr == null) AppState.debug.value = "screenshot failed (code $lastShotErr)"
                else {
                    frames.tryEmit(fr)
                    try { processFrame(fr, lastCapAt - settings.captureDelayMs) }
                    catch (e: Exception) { AppState.debug.value = "err: ${e.javaClass.simpleName} ${e.message}".take(120) }
                    fr.bmp.recycle()
                }
            } else AppState.debug.value = "waiting: app not matched"
            delay(max(30L, 400L - (SystemClock.elapsedRealtime() - t0)))
        }
    }

    private suspend fun processFrame(fr: Frame, capAt: Long) {
        tracker.graceMs = settings.graceMs.toLong()
        val rd = try { timerFinder.read(fr) } catch (_: Exception) { null }
        if (rd != null) tracker.onReading(rd.seconds, capAt)
        timerDbg = if (rd == null) "timer: not read" else "timer: ${rd.seconds}s"
        val now = SystemClock.elapsedRealtime()
        AppState.timerText.value = tracker.remainingMs(now)?.takeIf { tracker.isActive(now) }?.let { "%.1f s".format(it / 1000f) } ?: "--"
        AppState.timerConfidence.value = tracker.confidence(now)

        if (AppState.busy.value) return                      // أثناء التنفيذ لا نرسم دوائر
        if (keyboardVisible()) { dropSeats(); return }
        val k = resources.displayMetrics.widthPixels / fr.w.toFloat()
        val raw = withContext(Dispatchers.Default) { seatDetector.detect(fr) }
        AppState.debug.value = "detected ${raw.size} seats, locked ${raw.count { it.locked }}, occupied ${raw.count { it.occupied }}\n$timerDbg"
        val seats = raw.filter { it.occupied && !isMine(it.sig) }.map {
            Seat("#${it.num}", it.cx * k, it.cy * k, it.r * k * (settings.sizePct / 100f), it.ring, it.col, it.row, it.sig, it.num)
        }
        lastSeats = seats
        if (raw.isEmpty()) { if (++misses >= 2) dropSeats() } else {
            misses = 0; AppState.seats.value = seats
            overlay.renderSeats(seats, AppState.selectedKey.value, AppState.mode.value == 1, { engine.onSeatTapped(it) }, { markMySeat(it) })
        }
        refreshBubble()
    }

    private fun dropSeats() { AppState.seats.value = emptyList(); overlay.clearSeats() }

    // ---------- أدوات للمحرّك ----------
    private fun reg(fr: Frame, r: FloatArray) =
        intArrayOf((r[0] * fr.w).toInt(), (r[1] * fr.h).toInt(), (r[2] * fr.w).toInt(), (r[3] * fr.h).toInt())

    /** ينتظر ظهور قالب داخل منطقة (نسب من الإطار) ويعيد مركزه بإحداثيات الشاشة، أو null عند انتهاء المهلة. */
    suspend fun awaitMatch(name: String, region: FloatArray, mults: FloatArray, maxScore: Float, timeoutMs: Long): ScreenPt? {
        var found: ScreenPt? = null
        withTimeoutOrNull(timeoutMs) {
            frames.first { fr ->
                val m = Matcher.findMulti(fr, templates, name, mults, reg(fr, region), 2, maxScore)
                if (m != null) {
                    val k = resources.displayMetrics.widthPixels / fr.w.toFloat()
                    found = ScreenPt((m.cx * k).toInt(), (m.cy * k).toInt(), m.score)
                }
                m != null
            }
        }
        return found
    }

    /** يتحقق أن القالب اختفى من المنطقة (بعد مهلة قصيرة لتحديث الواجهة). */
    suspend fun awaitAbsent(name: String, region: FloatArray, maxScore: Float, minDelayMs: Long, timeoutMs: Long): Boolean {
        delay(minDelayMs)
        return withTimeoutOrNull(timeoutMs) {
            frames.first { fr -> Matcher.findMulti(fr, templates, name, floatArrayOf(1f), reg(fr, region), 2, maxScore) == null }
            true
        } ?: false
    }

    suspend fun tapPx(x: Int, y: Int): Boolean = suspendCancellableCoroutine { cont ->
        val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 40)).build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { if (cont.isActive) cont.resume(true) }
            override fun onCancelled(d: GestureDescription?) { if (cont.isActive) cont.resume(false) }
        }, null)
        if (!ok && cont.isActive) cont.resume(false)
    }

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable && n.isVisibleToUser) return n
        for (i in 0 until n.childCount) findEditable(n.getChild(i))?.let { return it }
        return null
    }
    private fun input(): AccessibilityNodeInfo? =
        rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(rootInActiveWindow)

    fun inputText(): String? = input()?.also { it.refresh() }?.text?.toString()

    /** يلصق " ." أو " .." في نهاية الحقل دون المساس بمنشن اللاعب الذي أضافه زر @. */
    fun appendSuffix(suffix: String): Boolean {
        val n = input() ?: return false
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("suffix", suffix))
        val len = n.text?.length ?: 0
        val b = Bundle().apply {
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, len)
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, len)
        }
        n.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, b)
        return n.performAction(AccessibilityNodeInfo.ACTION_PASTE)
    }

    companion object { @Volatile var instance: AssistService? = null }
}
