package com.example.mentionassist.core

import kotlinx.coroutines.flow.MutableStateFlow

/** سطر نص من OCR بإحداثيات نسبية (0..1) من عرض/ارتفاع الصورة. */
data class OcrLine(val text: String, val l: Float, val t: Float, val r: Float, val b: Float, val conf: Float) {
    val cx get() = (l + r) / 2
    val cy get() = (t + b) / 2
    val h get() = b - t
}

/** مقعد لاعب مكتشف. الإحداثيات بالبكسل على الشاشة الفعلية. */
data class Seat(val name: String, val cx: Float, val cy: Float, val r: Float, val conf: Float, val col: Int, val row: Int,
                val sig: ByteArray? = null) {
    val key get() = "$row,$col"
}

fun normalize(s: String) = s.trim().lowercase()

data class LogEntry(val timeMs: Long, val text: String, val status: String)

/** حالة مشتركة بين الخدمة والواجهة. */
object AppState {
    val running = MutableStateFlow(false)
    val serviceConnected = MutableStateFlow(false)
    val status = MutableStateFlow("متوقف")
    val seats = MutableStateFlow<List<Seat>>(emptyList())
    val selectedKey = MutableStateFlow<String?>(null)
    val timerText = MutableStateFlow("--")
    val timerConfidence = MutableStateFlow(0f)
    val foregroundPkg = MutableStateFlow("")
    val pendingConfirm = MutableStateFlow<String?>(null)
    val busy = MutableStateFlow(false)
    val log = MutableStateFlow<List<LogEntry>>(emptyList())
    val debug = MutableStateFlow("")

    fun addLog(text: String, status: String) {
        log.value = (listOf(LogEntry(System.currentTimeMillis(), text, status)) + log.value).take(100)
    }
}
